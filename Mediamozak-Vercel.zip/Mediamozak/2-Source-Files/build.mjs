// Mediamozak static site builder — run: node build.mjs
// Generates real HTML pages in /dist (ready for Vercel), then compiles Tailwind CSS.
import fs from "node:fs";
import path from "node:path";
import { execSync } from "node:child_process";
import { icons } from "lucide";
import { site, contact, whatsapp, socials, about, images, services, faqs, legal } from "./content.mjs";

const DIST = "dist";
fs.rmSync(DIST, { recursive: true, force: true });
fs.mkdirSync(DIST, { recursive: true });
fs.cpSync("src", DIST, { recursive: true });

// ---------- helpers ----------
const esc = (s = "") =>
  String(s).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");

function icon(name, cls = "w-5 h-5") {
  const node = icons[name];
  if (!node) throw new Error(`Unknown icon: ${name}`);
  const kids = node.map(([tag, attrs]) => `<${tag} ${Object.entries(attrs).map(([k, v]) => `${k}="${v}"`).join(" ")}/>`).join("");
  return `<svg xmlns="http://www.w3.org/2000/svg" class="${cls}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${kids}</svg>`;
}

// Photo with graceful fallback: if the image fails to load it hides and the gradient behind it shows.
const photo = (src, alt, cls, eager = false) =>
  `<img src="${esc(src)}" alt="${esc(alt)}" class="${cls}" ${eager ? 'fetchpriority="high"' : 'loading="lazy"'} decoding="async" onerror="this.style.display='none'">`;

const fill = (s) => s.replaceAll("{URL}", site.url).replaceAll("{EMAIL}", contact.email).replaceAll("{PHONE}", contact.phone);

const SOCIAL_SVGS = {
  facebook: `<svg class="w-4 h-4 fill-current" viewBox="0 0 24 24" aria-hidden="true"><path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z"/></svg>`,
  instagram: `<svg class="w-4 h-4 fill-current" viewBox="0 0 24 24" aria-hidden="true"><path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zm0-2.163c-3.259 0-3.667.014-4.947.072-4.358.2-6.78 2.618-6.98 6.98-.059 1.281-.073 1.689-.073 4.948 0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98 1.281.058 1.689.072 4.948.072 3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98-1.281-.059-1.69-.073-4.949-.073zm0 5.838c-3.403 0-6.162 2.759-6.162 6.162s2.759 6.163 6.162 6.163 6.162-2.759 6.162-6.163c0-3.403-2.759-6.162-6.162-6.162zm0 10.162c-2.209 0-4-1.79-4-4 0-2.209 1.791-4 4-4s4 1.791 4 4c0 2.21-1.791 4-4 4zm6.406-11.845c-.796 0-1.441.645-1.441 1.44s.645 1.44 1.441 1.44c.795 0 1.439-.645 1.439-1.44s-.644-1.44-1.439-1.44z"/></svg>`,
  linkedin: `<svg class="w-4 h-4 fill-current" viewBox="0 0 24 24" aria-hidden="true"><path d="M19 0h-14c-2.761 0-5 2.239-5 5v14c0 2.761 2.239 5 5 5h14c2.762 0 5-2.239 5-5v-14c0-2.761-2.238-5-5-5zm-11 19h-3v-11h3v11zm-1.5-12.268c-.966 0-1.75-.79-1.75-1.764s.784-1.764 1.75-1.764 1.75.79 1.75 1.764-.783 1.764-1.75 1.764zm13.5 12.268h-3v-5.604c0-3.368-4-3.113-4 0v5.604h-3v-11h3v1.765c1.396-2.586 7-2.777 7 2.476v6.759z"/></svg>`,
  youtube: `<svg class="w-4 h-4 fill-current" viewBox="0 0 24 24" aria-hidden="true"><path d="M23.498 6.186a3.016 3.016 0 0 0-2.122-2.136C19.505 3.545 12 3.545 12 3.545s-7.505 0-9.377.505A3.017 3.017 0 0 0 .502 6.186C0 8.07 0 12 0 12s0 3.93.502 5.814a3.016 3.016 0 0 0 2.122 2.136c1.871.505 9.376.505 9.376.505s7.505 0 9.377-.505a3.015 3.015 0 0 0 2.122-2.136C24 15.93 24 12 24 12s0-3.93-.502-5.814zM9.545 15.568V8.432L15.818 12l-6.273 3.568z"/></svg>`,
  whatsapp: `<svg class="w-6 h-6 fill-current" viewBox="0 0 24 24" aria-hidden="true"><path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/></svg>`,
};
const SOCIAL_LABELS = { instagram: "Instagram", facebook: "Facebook", linkedin: "LinkedIn", youtube: "YouTube" };

const waUrl = `https://wa.me/${whatsapp.number}?text=${encodeURIComponent(whatsapp.message)}`;
const mapsUrl = `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(contact.address)}`;
const svcUrl = (s) => `/services/${s.slug}/`;

// ---------- shared layout ----------
const NAV = [
  { href: "/", label: "Home", key: "home" },
  { href: "/about/", label: "About Us", key: "about" },
  { href: "/services/", label: "Services", key: "services", dropdown: true },
  { href: "/faqs/", label: "FAQs", key: "faqs" },
  { href: "/contact/", label: "Contact Us", key: "contact" },
];

function header(active) {
  const link = (n) => {
    const on = n.key === active;
    const cls = `${on ? "text-brand-gold" : "text-gray-300"} hover:text-brand-gold px-3 py-2 rounded-md transition-colors`;
    if (!n.dropdown) return `<a href="${n.href}" class="${cls}"${on ? ' aria-current="page"' : ""}>${n.label}</a>`;
    return `
      <div class="relative group">
        <a href="${n.href}" class="${cls} flex items-center gap-1"${on ? ' aria-current="page"' : ""}>
          <span>${n.label}</span>${icon("ChevronDown", "w-4 h-4 transition-transform group-hover:rotate-180 group-focus-within:rotate-180")}
        </a>
        <div class="absolute left-0 top-full pt-2 w-72 opacity-0 invisible group-hover:opacity-100 group-hover:visible group-focus-within:opacity-100 group-focus-within:visible transition-all duration-200 z-50">
          <div class="bg-gray-900 border border-gray-800 rounded-xl shadow-2xl p-2 space-y-1">
            ${services.map((s) => `
            <a href="${svcUrl(s)}" class="px-3 py-2 text-xs text-gray-300 hover:text-white hover:bg-gray-800 rounded-lg transition-colors flex items-center gap-2">
              ${icon(s.icon, "w-3.5 h-3.5 text-brand-gold flex-shrink-0")}<span class="truncate">${esc(s.title)}</span>
            </a>`).join("")}
          </div>
        </div>
      </div>`;
  };

  return `
  <a href="#main" class="sr-only focus:not-sr-only focus:fixed focus:top-2 focus:left-2 focus:z-[60] focus:bg-brand-gold focus:text-gray-950 focus:px-4 focus:py-2 focus:rounded-lg">Skip to content</a>
  <header class="sticky top-0 z-40 glass-header border-b border-gray-800">
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-20 md:h-24 flex items-center justify-between">
      <a href="/" class="flex items-center" aria-label="${esc(site.name)} Consulting home">
        <img src="/assets/img/logo-full.png" alt="${esc(site.name)} Consulting logo" width="213" height="267" class="h-16 md:h-[76px] w-auto">
      </a>

      <nav class="hidden md:flex items-center space-x-1 lg:space-x-4 text-sm font-medium" aria-label="Main">
        ${NAV.map(link).join("")}
      </nav>

      <div class="hidden md:flex items-center gap-3">
        <a href="/contact/" class="gold-bg-gradient text-gray-950 font-semibold px-4 py-2 rounded-lg text-sm hover:opacity-90 transition-all shadow-lg shadow-brand-gold/10 flex items-center gap-1.5">
          <span>Get Consultation</span>${icon("ArrowRight", "w-4 h-4")}
        </a>
      </div>

      <button id="menu-toggle" type="button" class="md:hidden text-gray-300 hover:text-white p-2" aria-label="Open menu" aria-expanded="false" aria-controls="mobile-menu">
        <span class="icon-open">${icon("Menu", "w-6 h-6")}</span>
        <span class="icon-close hidden">${icon("X", "w-6 h-6")}</span>
      </button>
    </div>

    <div id="mobile-menu" class="hidden md:hidden bg-gray-900 border-b border-gray-800 px-4 pt-2 pb-6 space-y-1 max-h-[calc(100vh-6rem)] overflow-y-auto">
      ${NAV.filter((n) => !n.dropdown).slice(0, 2).map((n) => `<a href="${n.href}" class="block py-2 ${n.key === active ? "text-brand-gold" : "text-gray-200"} hover:text-brand-gold font-medium">${n.label}</a>`).join("")}
      <div class="py-2 border-y border-gray-800/80 my-1">
        <a href="/services/" class="text-xs uppercase font-bold ${active === "services" ? "text-brand-gold" : "text-gray-500"} tracking-wider hover:text-brand-gold">Our Services</a>
        <div class="mt-2 space-y-1 pl-2">
          ${services.map((s) => `<a href="${svcUrl(s)}" class="flex items-center gap-2 py-1.5 text-sm text-gray-300 hover:text-white">${icon(s.icon, "w-4 h-4 text-brand-gold")}<span>${esc(s.title)}</span></a>`).join("")}
        </div>
      </div>
      ${NAV.slice(3).map((n) => `<a href="${n.href}" class="block py-2 ${n.key === active ? "text-brand-gold" : "text-gray-200"} hover:text-brand-gold font-medium">${n.label}</a>`).join("")}
      <a href="/contact/" class="mt-3 gold-bg-gradient text-gray-950 font-semibold px-4 py-3 rounded-lg text-sm flex items-center justify-center gap-1.5">Get Consultation ${icon("ArrowRight", "w-4 h-4")}</a>
    </div>
  </header>`;
}

function footer() {
  return `
  <footer class="bg-gray-900 border-t border-gray-800 pt-16 pb-8 text-gray-400 text-sm">
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
      <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-12 gap-10 pb-12 border-b border-gray-800">
        <div class="lg:col-span-4 space-y-4">
          <a href="/" class="inline-block" aria-label="${esc(site.name)} home">
            <img src="/assets/img/logo-full.png" alt="${esc(site.name)} Consulting logo" width="213" height="267" loading="lazy" class="h-[76px] w-auto">
          </a>
          <p class="text-gray-400 text-sm leading-relaxed max-w-sm">${esc(about.subheading)}</p>
          <div class="flex items-center gap-3 pt-2">
            ${Object.entries(socials).filter(([, u]) => u).map(([k, u]) => `
            <a href="${esc(u)}" target="_blank" rel="noopener noreferrer" aria-label="${SOCIAL_LABELS[k]}" title="${SOCIAL_LABELS[k]}" class="w-9 h-9 rounded-lg bg-gray-800 hover:bg-brand-gold hover:text-gray-950 text-gray-300 flex items-center justify-center transition-colors">${SOCIAL_SVGS[k]}</a>`).join("")}
          </div>
        </div>

        <div class="lg:col-span-2">
          <h2 class="text-white font-semibold text-base mb-4">Quick Links</h2>
          <ul class="space-y-2">
            <li><a href="/" class="hover:text-brand-gold transition-colors">Home</a></li>
            <li><a href="/about/" class="hover:text-brand-gold transition-colors">About Us</a></li>
            <li><a href="/services/" class="hover:text-brand-gold transition-colors">Services</a></li>
            <li><a href="/faqs/" class="hover:text-brand-gold transition-colors">FAQs</a></li>
            <li><a href="/contact/" class="hover:text-brand-gold transition-colors">Contact Us</a></li>
          </ul>
        </div>

        <div class="lg:col-span-3">
          <h2 class="text-white font-semibold text-base mb-4">Services</h2>
          <ul class="space-y-2">
            ${services.map((s) => `<li><a href="${svcUrl(s)}" class="hover:text-brand-gold transition-colors">${esc(s.title)}</a></li>`).join("")}
          </ul>
        </div>

        <div class="lg:col-span-3">
          <h2 class="text-white font-semibold text-base mb-4">Get in Touch</h2>
          <ul class="space-y-3">
            <li><a href="tel:${contact.phoneLink}" class="flex items-start gap-2.5 hover:text-brand-gold transition-colors">${icon("Phone", "w-4 h-4 text-brand-gold flex-shrink-0 mt-0.5")}<span>${esc(contact.phone)}</span></a></li>
            <li><a href="${esc(waUrl)}" target="_blank" rel="noopener noreferrer" class="flex items-start gap-2.5 hover:text-brand-gold transition-colors"><span class="text-[#25D366] flex-shrink-0 mt-0.5">${SOCIAL_SVGS.whatsapp.replace("w-6 h-6", "w-4 h-4")}</span><span>WhatsApp: ${esc(contact.phone)}</span></a></li>
            <li><a href="mailto:${contact.email}" class="flex items-start gap-2.5 hover:text-brand-gold transition-colors break-all">${icon("Mail", "w-4 h-4 text-brand-gold flex-shrink-0 mt-0.5")}<span>${esc(contact.email)}</span></a></li>
            <li><a href="${mapsUrl}" target="_blank" rel="noopener noreferrer" class="flex items-start gap-2.5 hover:text-brand-gold transition-colors">${icon("MapPin", "w-4 h-4 text-brand-gold flex-shrink-0 mt-0.5")}<span>${esc(contact.address)}</span></a></li>
            <li class="flex items-start gap-2.5">${icon("Clock", "w-4 h-4 text-brand-gold flex-shrink-0 mt-0.5")}<span>${esc(contact.workingHours)}</span></li>
          </ul>
        </div>
      </div>

      <div class="pt-8 flex flex-col md:flex-row items-center justify-between gap-4 text-xs text-gray-500">
        <p>&copy; ${new Date().getFullYear()} ${esc(site.name)}. All rights reserved.</p>
        <div class="flex items-center gap-5">
          <a href="/privacy-policy/" class="hover:text-brand-gold transition-colors">Privacy Policy</a>
          <a href="/terms-and-conditions/" class="hover:text-brand-gold transition-colors">Terms &amp; Conditions</a>
        </div>
      </div>
    </div>
  </footer>

  ${whatsapp.enabled ? `
  <a href="${esc(waUrl)}" target="_blank" rel="noopener noreferrer" aria-label="Chat with us on WhatsApp" class="fixed bottom-5 right-5 z-30 bg-[#25D366] hover:bg-[#1ebe5b] text-white p-3.5 rounded-full shadow-2xl flex items-center justify-center transition-transform duration-300 hover:scale-110 group">
    ${SOCIAL_SVGS.whatsapp}
    <span class="hidden sm:block absolute right-full mr-3 bg-gray-900 text-white text-xs font-semibold px-3 py-1.5 rounded-lg whitespace-nowrap border border-gray-800 opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none shadow-xl">Chat with us on WhatsApp</span>
  </a>` : ""}`;
}

function trackingHead() {
  let h = "";
  if (site.googleSiteVerification) h += `\n  <meta name="google-site-verification" content="${esc(site.googleSiteVerification)}">`;
  if (site.ga4MeasurementId)
    h += `\n  <script async src="https://www.googletagmanager.com/gtag/js?id=${esc(site.ga4MeasurementId)}"></script>
  <script>window.dataLayer=window.dataLayer||[];function gtag(){dataLayer.push(arguments);}gtag('js',new Date());gtag('config','${esc(site.ga4MeasurementId)}');</script>`;
  if (site.metaPixelId)
    h += `\n  <script>!function(f,b,e,v,n,t,s){if(f.fbq)return;n=f.fbq=function(){n.callMethod?n.callMethod.apply(n,arguments):n.queue.push(arguments)};if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';n.queue=[];t=b.createElement(e);t.async=!0;t.src=v;s=b.getElementsByTagName(e)[0];s.parentNode.insertBefore(t,s)}(window,document,'script','https://connect.facebook.net/en_US/fbevents.js');fbq('init','${esc(site.metaPixelId)}');fbq('track','PageView');</script>`;
  return h;
}

const ORG_LD = {
  "@context": "https://schema.org",
  "@type": "ProfessionalService",
  name: site.name,
  alternateName: `${site.name} Consulting`,
  url: site.url + "/",
  logo: site.url + "/assets/img/icon-512.png",
  image: site.url + "/assets/img/og-image.jpg",
  description: site.description,
  telephone: contact.phoneLink,
  email: contact.email,
  address: { "@type": "PostalAddress", streetAddress: "Hari Nagar", addressLocality: "West Delhi", addressRegion: "Delhi", postalCode: "110064", addressCountry: "IN" },
  openingHoursSpecification: [{ "@type": "OpeningHoursSpecification", dayOfWeek: ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"], opens: "09:00", closes: "19:00" }],
  areaServed: "IN",
  sameAs: Object.values(socials).filter(Boolean),
};

function layout({ title, description, urlPath, active, body, noindex = false, jsonld = [] }) {
  const canonical = site.url + urlPath;
  const fullTitle = title ? `${title} | ${site.name}` : site.title;
  const desc = description || site.description;
  return `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>${esc(fullTitle)}</title>
  <meta name="description" content="${esc(desc)}">
  ${noindex ? '<meta name="robots" content="noindex, follow">' : `<link rel="canonical" href="${canonical}">`}
  <meta name="theme-color" content="#030712">
  <link rel="icon" href="/favicon.ico" sizes="48x48">
  <link rel="icon" type="image/png" sizes="32x32" href="/assets/img/favicon-32.png">
  <link rel="apple-touch-icon" href="/assets/img/apple-touch-icon.png">
  <link rel="manifest" href="/site.webmanifest">
  <meta property="og:type" content="website">
  <meta property="og:site_name" content="${esc(site.name)}">
  <meta property="og:title" content="${esc(fullTitle)}">
  <meta property="og:description" content="${esc(desc)}">
  <meta property="og:url" content="${canonical}">
  <meta property="og:image" content="${site.url}/assets/img/og-image.jpg">
  <meta property="og:image:width" content="1200">
  <meta property="og:image:height" content="630">
  <meta name="twitter:card" content="summary_large_image">
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="/assets/css/site.css">${trackingHead()}
  ${jsonld.map((j) => `<script type="application/ld+json">${JSON.stringify(j)}</script>`).join("\n  ")}
</head>
<body class="bg-gray-950 text-gray-100 min-h-screen flex flex-col font-sans antialiased selection:bg-brand-gold selection:text-gray-900">
  ${header(active)}
  <main id="main" class="flex-grow">
${body}
  </main>
  ${footer()}
  <script src="/assets/js/site.js" defer></script>
</body>
</html>
`;
}

function write(urlPath, html) {
  const file = urlPath.endsWith(".html") ? path.join(DIST, urlPath) : path.join(DIST, urlPath, "index.html");
  fs.mkdirSync(path.dirname(file), { recursive: true });
  fs.writeFileSync(file, html);
}

const breadcrumb = (items) => `
        <nav class="flex flex-wrap items-center gap-2 text-xs text-gray-400 mb-8" aria-label="Breadcrumb">
          ${items.map(([label, href], i) => (href ? `<a href="${href}" class="hover:text-white">${esc(label)}</a><span aria-hidden="true">/</span>` : `<span class="text-brand-gold font-medium" aria-current="page">${esc(label)}</span>`)).join("")}
        </nav>`;

const ctaBand = (heading = "Ready to Accelerate Your Brand Growth?", text = "Speak with our team and discover how tailored marketing funnels and a custom tech stack can grow your revenue.") => `
    <section class="py-16 bg-gray-950 border-t border-gray-800">
      <div class="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
        <div class="bg-gradient-to-r from-gray-900 to-gray-800 border border-brand-gold/30 rounded-3xl p-8 sm:p-12 text-center">
          <h2 class="text-2xl sm:text-4xl font-bold text-white mb-4">${heading}</h2>
          <p class="text-gray-300 max-w-2xl mx-auto text-sm sm:text-base mb-8">${text}</p>
          <div class="flex flex-col sm:flex-row items-center justify-center gap-3">
            <a href="/contact/" class="w-full sm:w-auto inline-flex items-center justify-center gap-2 gold-bg-gradient text-gray-950 font-bold px-8 py-3.5 rounded-xl text-sm hover:opacity-90 transition-all shadow-xl">Schedule Consultation ${icon("ArrowRight", "w-4 h-4")}</a>
            <a href="${esc(waUrl)}" target="_blank" rel="noopener noreferrer" class="w-full sm:w-auto inline-flex items-center justify-center gap-2 bg-gray-950 border border-gray-700 hover:border-[#25D366] text-white font-semibold px-8 py-3.5 rounded-xl text-sm transition-colors"><span class="text-[#25D366]">${SOCIAL_SVGS.whatsapp.replace("w-6 h-6", "w-4 h-4")}</span> WhatsApp Us</a>
          </div>
        </div>
      </div>
    </section>`;

const statCard = (s) => `
            <div class="p-4 bg-gray-900/60 border border-gray-800 rounded-2xl">
              <p class="text-3xl font-extrabold text-brand-gold">${esc(s.value)}</p>
              <p class="text-xs text-gray-400 mt-1 uppercase font-medium">${esc(s.label)}</p>
            </div>`;

// ---------- pages ----------
// HOME
write("/", layout({
  urlPath: "/",
  active: "home",
  jsonld: [ORG_LD],
  body: `
    <section class="relative bg-gray-950 py-20 lg:py-32 overflow-hidden border-b border-gray-800">
      <div class="absolute inset-0 z-0 opacity-20 bg-gradient-to-br from-brand-dark to-gray-950">
        ${photo(images.homeBanner, "", "w-full h-full object-cover", true)}
      </div>
      <div class="absolute inset-0 z-0 bg-gradient-to-t from-gray-950 via-gray-950/80 to-transparent"></div>
      <div class="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
        <div class="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-brand-gold/10 border border-brand-gold/30 text-brand-gold text-xs font-semibold uppercase tracking-wider mb-6">
          ${icon("Sparkles", "w-4 h-4")}<span>Results-Driven Digital Growth Agency</span>
        </div>
        <h1 class="text-4xl sm:text-6xl lg:text-7xl font-extrabold text-white tracking-tight leading-tight max-w-4xl mx-auto">
          Scale Your Brand With <span class="gold-gradient-text">Precision Marketing</span> &amp; Code
        </h1>
        <p class="mt-6 text-lg sm:text-xl text-gray-300 max-w-2xl mx-auto font-light leading-relaxed">${esc(about.subheading)}</p>
        <div class="mt-10 flex flex-col sm:flex-row items-center justify-center gap-4">
          <a href="/contact/" class="w-full sm:w-auto gold-bg-gradient text-gray-950 font-bold px-8 py-4 rounded-xl hover:opacity-95 transition-all text-base shadow-xl flex items-center justify-center gap-2">
            <span>Get Free Strategy Call</span>${icon("ArrowRight", "w-5 h-5")}
          </a>
          <a href="/services/" class="w-full sm:w-auto bg-gray-900 hover:bg-gray-800 text-white border border-gray-700 font-semibold px-8 py-4 rounded-xl transition-all text-base flex items-center justify-center gap-2">Explore Services</a>
        </div>
        <div class="mt-16 grid grid-cols-2 md:grid-cols-4 gap-4 sm:gap-6 pt-12 border-t border-gray-800/80 max-w-4xl mx-auto">
          ${about.stats.map(statCard).join("")}
        </div>
      </div>
    </section>

    <section class="py-20 bg-gray-900">
      <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div class="text-center max-w-3xl mx-auto mb-16">
          <p class="text-xs font-bold text-brand-gold uppercase tracking-widest mb-2">Capabilities</p>
          <h2 class="text-3xl sm:text-4xl font-bold text-white">Full-Funnel Digital Services</h2>
          <p class="text-gray-400 text-sm mt-3">From fast enterprise web applications to hyper-targeted performance advertising.</p>
        </div>
        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 lg:[&>*:last-child:nth-child(3n+1)]:col-start-2">
          ${services.map((s) => `
          <a href="${svcUrl(s)}" class="bg-gray-950 border border-gray-800 hover:border-brand-gold/50 rounded-2xl p-6 transition-all duration-300 hover:-translate-y-1 group flex flex-col justify-between">
            <div>
              <div class="w-12 h-12 rounded-xl bg-brand-gold/10 border border-brand-gold/30 flex items-center justify-center text-brand-gold mb-6 group-hover:bg-brand-gold group-hover:text-gray-950 transition-colors">${icon(s.icon, "w-6 h-6")}</div>
              <h3 class="text-xl font-bold text-white mb-3 group-hover:text-brand-gold transition-colors">${esc(s.title)}</h3>
              <p class="text-gray-400 text-sm leading-relaxed mb-6">${esc(s.shortDesc)}</p>
            </div>
            <span class="inline-flex items-center gap-2 text-brand-gold font-semibold text-sm pt-4 border-t border-gray-800/80">Learn More ${icon("ArrowRight", "w-4 h-4 transition-transform group-hover:translate-x-1")}</span>
          </a>`).join("")}
        </div>
      </div>
    </section>
${ctaBand()}`,
}));

// ABOUT
write("/about/", layout({
  title: "About Us",
  description: `About ${site.name} — a data-driven growth marketing and web development agency in West Delhi helping brands scale with performance marketing, SEO and conversion-focused websites.`,
  urlPath: "/about/",
  active: "about",
  body: `
    <section class="py-16 bg-gray-950">
      <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div class="text-center max-w-3xl mx-auto mb-12">
          <p class="text-xs font-bold text-brand-gold uppercase tracking-widest">About ${esc(site.name)}</p>
          <h1 class="text-3xl sm:text-5xl font-extrabold text-white mt-2 mb-4">${esc(about.heading)}</h1>
          <p class="text-gray-300 text-base leading-relaxed">${esc(about.subheading)}</p>
        </div>
        <div class="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center mt-12">
          <div class="relative rounded-2xl overflow-hidden border border-gray-800 shadow-2xl aspect-[3/2] bg-gradient-to-br from-brand-dark to-gray-900 flex items-center justify-center">
            <img src="/assets/img/logo-mark.png" alt="" class="absolute w-32 opacity-30" aria-hidden="true">
            ${photo(about.teamImage, `${site.name} team at work`, "relative w-full h-full object-cover")}
          </div>
          <div class="space-y-6">
            <h2 class="text-2xl font-bold text-white">Engineering Growth for Modern Digital Enterprises</h2>
            <p class="text-gray-400 text-sm leading-relaxed">${esc(about.mission)}</p>
            <div class="grid grid-cols-2 gap-4 pt-4">
              ${about.stats.map((s) => `
              <div class="p-4 bg-gray-900 border border-gray-800 rounded-xl">
                <div class="text-2xl font-bold text-brand-gold">${esc(s.value)}</div>
                <div class="text-xs text-gray-400 mt-1">${esc(s.label)}</div>
              </div>`).join("")}
            </div>
            <div class="pt-6">
              <a href="/contact/" class="gold-bg-gradient text-gray-950 font-semibold px-6 py-3 rounded-lg text-sm inline-flex items-center gap-2">Work With Us ${icon("ArrowRight", "w-4 h-4")}</a>
            </div>
          </div>
        </div>
      </div>
    </section>

    <section class="py-16 bg-gray-900 border-t border-gray-800">
      <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <h2 class="text-2xl sm:text-3xl font-bold text-white text-center mb-10">What We Do</h2>
        <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          ${services.map((s) => `
          <a href="${svcUrl(s)}" class="flex items-center gap-3 p-4 bg-gray-950 border border-gray-800 hover:border-brand-gold/50 rounded-xl transition-colors group">
            <span class="w-10 h-10 rounded-lg bg-brand-gold/10 border border-brand-gold/30 flex items-center justify-center text-brand-gold flex-shrink-0">${icon(s.icon, "w-5 h-5")}</span>
            <span class="text-sm font-semibold text-gray-200 group-hover:text-brand-gold">${esc(s.title)}</span>
          </a>`).join("")}
        </div>
      </div>
    </section>
${ctaBand()}`,
}));

// SERVICES LIST
write("/services/", layout({
  title: "Digital Marketing & Web Development Services",
  description: `Explore ${site.name} services: ${services.map((s) => s.title).join(", ")}.`,
  urlPath: "/services/",
  active: "services",
  body: `
    <section class="py-16 bg-gray-950">
      <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div class="text-center max-w-3xl mx-auto mb-16">
          <p class="text-xs font-bold text-brand-gold uppercase tracking-widest">Our Expertise</p>
          <h1 class="text-3xl sm:text-5xl font-extrabold text-white mt-2">Comprehensive Marketing &amp; Tech Services</h1>
          <p class="text-gray-400 text-sm mt-3">Select a service to view specialized capabilities and deliverables.</p>
        </div>
        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 lg:[&>*:last-child:nth-child(3n+1)]:col-start-2">
          ${services.map((s) => `
          <a href="${svcUrl(s)}" class="bg-gray-900 border border-gray-800 rounded-2xl overflow-hidden hover:border-brand-gold/50 transition-all group flex flex-col">
            <div class="h-48 overflow-hidden relative bg-gradient-to-br from-brand-dark to-gray-900 flex items-center justify-center">
              <span class="absolute text-brand-gold/30">${icon(s.icon, "w-16 h-16")}</span>
              ${photo(s.bannerImage, s.title, "relative w-full h-full object-cover group-hover:scale-105 transition-transform duration-500")}
              <div class="absolute inset-0 bg-gradient-to-t from-gray-900 via-transparent to-transparent"></div>
            </div>
            <div class="p-6 flex-grow flex flex-col justify-between">
              <div>
                <h2 class="text-xl font-bold text-white mb-2 group-hover:text-brand-gold transition-colors">${esc(s.title)}</h2>
                <p class="text-gray-400 text-sm leading-relaxed mb-4">${esc(s.shortDesc)}</p>
              </div>
              <span class="w-full bg-gray-800 group-hover:bg-brand-gold group-hover:text-gray-950 text-white text-xs font-semibold py-2.5 rounded-lg transition-colors flex items-center justify-center gap-2 mt-4">Explore Service ${icon("ArrowRight", "w-3.5 h-3.5")}</span>
            </div>
          </a>`).join("")}
        </div>
      </div>
    </section>
${ctaBand()}`,
}));

// SINGLE SERVICES
for (const s of services) {
  const others = services.filter((o) => o.slug !== s.slug);
  write(svcUrl(s), layout({
    title: s.title,
    description: `${s.shortDesc} ${site.name} — ${s.title} in Delhi.`.slice(0, 300),
    urlPath: svcUrl(s),
    active: "services",
    jsonld: [
      { "@context": "https://schema.org", "@type": "Service", name: s.title, description: s.fullContent, serviceType: s.title, provider: { "@type": "ProfessionalService", name: site.name, url: site.url + "/" }, areaServed: "IN", url: site.url + svcUrl(s) },
      { "@context": "https://schema.org", "@type": "BreadcrumbList", itemListElement: [
        { "@type": "ListItem", position: 1, name: "Home", item: site.url + "/" },
        { "@type": "ListItem", position: 2, name: "Services", item: site.url + "/services/" },
        { "@type": "ListItem", position: 3, name: s.title, item: site.url + svcUrl(s) },
      ] },
    ],
    body: `
    <section class="py-16 bg-gray-950">
      <div class="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
        ${breadcrumb([["Home", "/"], ["Services", "/services/"], [s.title]])}
        <div class="relative rounded-3xl overflow-hidden border border-gray-800 h-64 sm:h-80 mb-10 bg-gradient-to-br from-brand-dark to-gray-900">
          ${photo(s.bannerImage, s.title, "w-full h-full object-cover", true)}
          <div class="absolute inset-0 bg-gradient-to-t from-gray-950 via-gray-950/60 to-transparent"></div>
          <div class="absolute bottom-6 left-6 right-6 sm:bottom-8 sm:left-8 sm:right-8">
            <span class="text-xs uppercase font-bold text-brand-gold tracking-widest bg-brand-gold/10 px-3 py-1 rounded-full border border-brand-gold/30">Service Overview</span>
            <h1 class="text-3xl sm:text-5xl font-extrabold text-white mt-3">${esc(s.title)}</h1>
          </div>
        </div>
        <div class="grid grid-cols-1 lg:grid-cols-3 gap-10">
          <div class="lg:col-span-2 space-y-8">
            <div>
              <h2 class="text-xl font-bold text-white mb-3">Service Deep Dive</h2>
              <p class="text-gray-300 text-base leading-relaxed">${esc(s.fullContent)}</p>
            </div>
            <div class="bg-gray-900 border border-gray-800 rounded-2xl p-6">
              <h2 class="text-lg font-bold text-white mb-4 flex items-center gap-2">${icon("CircleCheck", "w-5 h-5 text-emerald-400")}<span>Key Capabilities &amp; Deliverables</span></h2>
              <ul class="grid grid-cols-1 sm:grid-cols-2 gap-3">
                ${s.features.map((f) => `<li class="flex items-center gap-2 text-sm text-gray-300 bg-gray-950 p-3 rounded-lg border border-gray-800">${icon("Check", "w-4 h-4 text-brand-gold flex-shrink-0")}<span>${esc(f)}</span></li>`).join("")}
              </ul>
            </div>
          </div>
          <aside class="space-y-6">
            <div class="bg-gray-900 border border-gray-800 rounded-2xl p-6 text-center lg:sticky lg:top-32">
              <h2 class="text-lg font-bold text-white mb-2">Need ${esc(s.title)}?</h2>
              <p class="text-sm text-gray-400 mb-6">Let's build a dedicated execution plan for your business today.</p>
              <a href="/contact/?service=${s.slug}" class="gold-bg-gradient text-gray-950 font-bold w-full py-3 rounded-xl text-sm flex items-center justify-center gap-2 shadow-lg">Book Quick Audit ${icon("ArrowRight", "w-4 h-4")}</a>
              <a href="tel:${contact.phoneLink}" class="mt-3 w-full py-3 rounded-xl text-sm flex items-center justify-center gap-2 bg-gray-950 border border-gray-800 hover:border-brand-gold/50 text-gray-200">${icon("Phone", "w-4 h-4 text-brand-gold")} ${esc(contact.phone)}</a>
            </div>
            <div class="bg-gray-900 border border-gray-800 rounded-2xl p-6">
              <h2 class="text-sm font-bold text-white mb-3">Other Services</h2>
              <ul class="space-y-1">
                ${others.map((o) => `<li><a href="${svcUrl(o)}" class="flex items-center gap-2 py-1.5 text-sm text-gray-400 hover:text-brand-gold">${icon(o.icon, "w-4 h-4 text-brand-gold")}${esc(o.title)}</a></li>`).join("")}
              </ul>
            </div>
          </aside>
        </div>
      </div>
    </section>
${ctaBand()}`,
  }));
}

// FAQS
write("/faqs/", layout({
  title: "Frequently Asked Questions",
  description: `Answers to common questions about working with ${site.name}: results timelines, retainers, quick commerce marketing and more.`,
  urlPath: "/faqs/",
  active: "faqs",
  jsonld: [{ "@context": "https://schema.org", "@type": "FAQPage", mainEntity: faqs.map((f) => ({ "@type": "Question", name: f.question, acceptedAnswer: { "@type": "Answer", text: f.answer } })) }],
  body: `
    <section class="py-16 bg-gray-950">
      <div class="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <div class="text-center max-w-2xl mx-auto mb-16">
          <p class="text-xs font-bold text-brand-gold uppercase tracking-widest">Help &amp; Answers</p>
          <h1 class="text-3xl sm:text-5xl font-extrabold text-white mt-2">Frequently Asked Questions</h1>
          <p class="text-gray-400 text-sm mt-3">Find clear answers regarding our onboarding, timeline, and agency workflow.</p>
        </div>
        <div class="space-y-4">
          ${faqs.map((f, i) => `
          <details class="faq bg-gray-900 border border-gray-800 rounded-2xl p-6 group"${i === 0 ? " open" : ""}>
            <summary class="flex items-start justify-between gap-4 cursor-pointer list-none">
              <h2 class="text-base sm:text-lg font-bold text-white flex items-start gap-3">
                <span class="w-6 h-6 rounded-full bg-brand-gold/10 text-brand-gold text-xs flex items-center justify-center flex-shrink-0 font-bold mt-0.5">${i + 1}</span>
                <span>${esc(f.question)}</span>
              </h2>
              <span class="flex items-center gap-2 flex-shrink-0">
                <span class="hidden sm:inline text-[10px] bg-gray-800 text-gray-400 px-2.5 py-1 rounded-full uppercase font-bold tracking-wider">${esc(f.category)}</span>
                ${icon("ChevronDown", "w-5 h-5 text-gray-400 transition-transform group-open:rotate-180")}
              </span>
            </summary>
            <p class="text-gray-400 text-sm mt-4 pl-9 leading-relaxed border-t border-gray-800/80 pt-3">${esc(f.answer)}</p>
          </details>`).join("")}
        </div>
        <p class="text-center text-sm text-gray-400 mt-10">Still have a question? <a href="/contact/" class="text-brand-gold hover:underline">Contact our team</a> or <a href="${esc(waUrl)}" target="_blank" rel="noopener noreferrer" class="text-brand-gold hover:underline">message us on WhatsApp</a>.</p>
      </div>
    </section>`,
}));

// CONTACT
const infoCard = (ic, title, value, href, ext = false) => `
            <${href ? `a href="${esc(href)}"${ext ? ' target="_blank" rel="noopener noreferrer"' : ""}` : "div"} class="bg-gray-900 border border-gray-800 ${href ? "hover:border-brand-gold/50" : ""} rounded-2xl p-5 flex items-start gap-4 transition-colors">
              <span class="p-3 bg-brand-gold/10 text-brand-gold rounded-xl border border-brand-gold/30 flex-shrink-0">${ic}</span>
              <span class="min-w-0">
                <span class="block text-sm font-bold text-white">${title}</span>
                <span class="block text-sm text-gray-400 mt-1 break-words">${esc(value)}</span>
              </span>
            </${href ? "a" : "div"}>`;

write("/contact/", layout({
  title: "Contact Us",
  description: `Contact ${site.name} in Hari Nagar, West Delhi. Call ${contact.phone}, email ${contact.email} or send an enquiry for a free strategy call.`,
  urlPath: "/contact/",
  active: "contact",
  jsonld: [ORG_LD],
  body: `
    <section class="py-16 bg-gray-950">
      <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div class="text-center max-w-2xl mx-auto mb-14">
          <p class="text-xs font-bold text-brand-gold uppercase tracking-widest">Contact Us</p>
          <h1 class="text-3xl sm:text-5xl font-extrabold text-white mt-2">Start Your Growth Journey</h1>
          <p class="text-gray-400 text-sm mt-3">Fill out the form or reach out directly to our strategist team.</p>
        </div>

        <div class="grid grid-cols-1 lg:grid-cols-5 gap-10">
          <div class="lg:col-span-2 space-y-4">
            ${infoCard(icon("Phone", "w-6 h-6"), "Call Us", contact.phone, `tel:${contact.phoneLink}`)}
            ${infoCard(SOCIAL_SVGS.whatsapp, "WhatsApp", contact.phone, waUrl, true)}
            ${infoCard(icon("Mail", "w-6 h-6"), "Email Us", contact.email, `mailto:${contact.email}`)}
            ${infoCard(icon("MapPin", "w-6 h-6"), "Our Office", contact.address, mapsUrl, true)}
            ${infoCard(icon("Clock", "w-6 h-6"), "Working Hours", contact.workingHours)}
          </div>

          <div class="lg:col-span-3 bg-gray-900 border border-gray-800 rounded-2xl p-6 sm:p-8">
            <div id="form-success" class="hidden text-center py-12" role="status" aria-live="polite">
              <div id="success-icon" class="w-16 h-16 mx-auto rounded-full bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 flex items-center justify-center mb-5">${icon("CircleCheck", "w-8 h-8")}</div>
              <h2 id="success-title" class="text-2xl font-bold text-white">Thank you! Your enquiry has been sent.</h2>
              <p id="success-text" class="text-gray-400 text-sm mt-3 max-w-md mx-auto">Our strategy team will get back to you shortly by email. For anything urgent, call <a href="tel:${contact.phoneLink}" class="text-brand-gold hover:underline">${esc(contact.phone)}</a>.</p>
              <a id="wa-again" href="#" target="_blank" rel="noopener noreferrer" class="hidden mt-6 inline-flex items-center gap-2 bg-[#25D366] hover:bg-[#1ebe5b] text-white font-bold px-6 py-3 rounded-xl text-sm">${SOCIAL_SVGS.whatsapp.replace("w-6 h-6", "w-5 h-5")} Open WhatsApp again</a>
            </div>

            <form id="contact-form" name="contact" method="POST" action="https://formsubmit.co/${contact.leadsEmail}" class="space-y-4" novalidate>
              <!-- Without JavaScript the form posts straight to FormSubmit, which emails the lead and returns to /thank-you/ -->
              <input type="hidden" name="_subject" value="Mediamozak Consulting – New Website Enquiry">
              <input type="hidden" name="_next" value="${site.url}/thank-you/">
              <input type="hidden" name="_template" value="table">
              <input type="hidden" name="_captcha" value="false">
              <p class="hidden" aria-hidden="true"><label>Leave this empty: <input name="_honey" tabindex="-1" autocomplete="off"></label></p>
              <h2 class="text-lg font-bold text-white mb-2">Send us an enquiry</h2>
              <div>
                <label for="lead-name" class="block text-xs font-medium text-gray-300 mb-1">Full Name <span class="text-brand-gold">*</span></label>
                <input type="text" id="lead-name" name="name" required autocomplete="name" maxlength="100" class="field" placeholder="Enter your full name">
              </div>
              <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label for="lead-email" class="block text-xs font-medium text-gray-300 mb-1">Email Address <span class="text-brand-gold">*</span></label>
                  <input type="email" id="lead-email" name="email" required autocomplete="email" maxlength="150" class="field" placeholder="name@company.com">
                </div>
                <div>
                  <label for="lead-phone" class="block text-xs font-medium text-gray-300 mb-1">Phone Number <span class="text-brand-gold">*</span></label>
                  <input type="tel" id="lead-phone" name="phone" required autocomplete="tel" pattern="[0-9+()\\-\\s]{7,20}" maxlength="20" class="field" placeholder="+91 ...">
                </div>
              </div>
              <div>
                <label for="lead-service" class="block text-xs font-medium text-gray-300 mb-1">Service Interested In</label>
                <select id="lead-service" name="service" class="field">
                  ${services.map((s) => `<option value="${esc(s.title)}" data-slug="${s.slug}">${esc(s.title)}</option>`).join("")}
                  <option value="Not sure yet">Not sure yet / Multiple services</option>
                </select>
              </div>
              <div>
                <label for="lead-message" class="block text-xs font-medium text-gray-300 mb-1">Project Details / Goals <span class="text-brand-gold">*</span></label>
                <textarea id="lead-message" name="message" rows="5" required maxlength="3000" class="field" placeholder="Describe your growth targets..."></textarea>
              </div>
              <p id="form-error" class="hidden text-sm text-rose-400 bg-rose-950/40 border border-rose-900/60 rounded-lg p-3" role="alert"></p>
              <input type="hidden" name="channel" id="lead-channel" value="Email">
              <div>
                <p class="block text-xs font-medium text-gray-300 mb-2">How would you like to send your enquiry?</p>
                <div class="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <button type="submit" data-channel="WhatsApp" class="w-full bg-[#25D366] hover:bg-[#1ebe5b] text-white font-bold py-3.5 rounded-lg text-sm transition-colors shadow-xl flex items-center justify-center gap-2 disabled:opacity-60 disabled:cursor-wait">
                    ${SOCIAL_SVGS.whatsapp.replace("w-6 h-6", "w-5 h-5")}<span class="btn-label">Send on WhatsApp</span>
                  </button>
                  <button type="submit" data-channel="Email" class="w-full gold-bg-gradient text-gray-950 font-bold py-3.5 rounded-lg text-sm hover:opacity-95 transition-all shadow-xl flex items-center justify-center gap-2 disabled:opacity-60 disabled:cursor-wait">
                    ${icon("Mail", "w-5 h-5")}<span class="btn-label">Send via Email</span>
                  </button>
                </div>
              </div>
              <p class="text-[11px] text-gray-500 text-center">By submitting, you agree to our <a href="/privacy-policy/" class="underline hover:text-brand-gold">Privacy Policy</a>.</p>
            </form>
          </div>
        </div>

        <div class="mt-12 rounded-2xl overflow-hidden border border-gray-800 h-72 bg-gray-900">
          <iframe title="Map showing ${esc(contact.address)}" src="https://www.google.com/maps?q=${encodeURIComponent("Hari Nagar, New Delhi, Delhi 110064")}&output=embed" class="w-full h-full" style="border:0" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
        </div>
      </div>
    </section>`,
}));

// THANK YOU (used when JS is disabled — FormSubmit returns visitors here after a normal form post)
write("/thank-you/", layout({
  title: "Thank You",
  urlPath: "/thank-you/",
  active: "contact",
  noindex: true,
  body: `
    <section class="py-24 bg-gray-950">
      <div class="max-w-xl mx-auto px-4 text-center">
        <div class="w-16 h-16 mx-auto rounded-full bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 flex items-center justify-center mb-6">${icon("CircleCheck", "w-8 h-8")}</div>
        <h1 class="text-3xl sm:text-4xl font-extrabold text-white">Thank you! Your enquiry has been sent.</h1>
        <p class="text-gray-400 mt-4">Our strategy team will get back to you shortly. For anything urgent, call <a href="tel:${contact.phoneLink}" class="text-brand-gold hover:underline">${esc(contact.phone)}</a>.</p>
        <a href="/" class="inline-flex items-center gap-2 mt-8 gold-bg-gradient text-gray-950 font-bold px-6 py-3 rounded-xl text-sm">Back to Home ${icon("ArrowRight", "w-4 h-4")}</a>
      </div>
    </section>`,
}));

// LEGAL
function legalPage(urlPath, title, sections) {
  write(urlPath, layout({
    title,
    description: `${title} for ${site.name} (${site.url.replace("https://", "")}).`,
    urlPath,
    body: `
    <section class="py-16 bg-gray-950">
      <div class="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        ${breadcrumb([["Home", "/"], [title]])}
        <h1 class="text-3xl sm:text-4xl font-extrabold text-white">${esc(title)}</h1>
        <p class="text-xs text-gray-500 mt-2">Last updated: ${esc(legal.updated)}</p>
        <div class="mt-8 bg-gray-900 border border-gray-800 rounded-2xl p-6 sm:p-8 space-y-6">
          ${sections.map(([h, p]) => `
          <div>
            <h2 class="text-lg font-bold text-white mb-2">${esc(h)}</h2>
            <p class="text-gray-300 text-sm sm:text-base leading-relaxed">${esc(fill(p))}</p>
          </div>`).join("")}
        </div>
      </div>
    </section>`,
  }));
}
legalPage("/privacy-policy/", "Privacy Policy", legal.privacy);
legalPage("/terms-and-conditions/", "Terms & Conditions", legal.terms);

// 404
write("/404.html", layout({
  title: "Page Not Found",
  urlPath: "/404.html",
  noindex: true,
  body: `
    <section class="py-24 bg-gray-950">
      <div class="max-w-xl mx-auto px-4 text-center">
        <p class="text-7xl font-extrabold gold-gradient-text">404</p>
        <h1 class="text-2xl sm:text-3xl font-bold text-white mt-4">This page doesn't exist</h1>
        <p class="text-gray-400 mt-3">The page you're looking for may have moved. Try one of these instead:</p>
        <div class="flex flex-wrap justify-center gap-3 mt-8">
          <a href="/" class="gold-bg-gradient text-gray-950 font-bold px-5 py-2.5 rounded-lg text-sm">Home</a>
          <a href="/services/" class="bg-gray-900 border border-gray-700 text-white px-5 py-2.5 rounded-lg text-sm">Services</a>
          <a href="/contact/" class="bg-gray-900 border border-gray-700 text-white px-5 py-2.5 rounded-lg text-sm">Contact Us</a>
        </div>
      </div>
    </section>`,
}));

// ---------- SEO / Vercel files ----------
const pages = ["/", "/about/", "/services/", ...services.map(svcUrl), "/faqs/", "/contact/", "/privacy-policy/", "/terms-and-conditions/"];
const today = new Date().toISOString().slice(0, 10);
fs.writeFileSync(path.join(DIST, "sitemap.xml"),
  `<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n${pages.map((p) => `  <url><loc>${site.url}${p}</loc><lastmod>${today}</lastmod></url>`).join("\n")}\n</urlset>\n`);
fs.writeFileSync(path.join(DIST, "robots.txt"), `User-agent: *\nAllow: /\nDisallow: /thank-you/\n\nSitemap: ${site.url}/sitemap.xml\n`);
fs.writeFileSync(path.join(DIST, "site.webmanifest"), JSON.stringify({
  name: `${site.name} ${site.tagline}`, short_name: site.name, start_url: "/", display: "standalone",
  background_color: "#030712", theme_color: "#030712",
  icons: [{ src: "/assets/img/icon-192.png", sizes: "192x192", type: "image/png" }, { src: "/assets/img/icon-512.png", sizes: "512x512", type: "image/png" }],
}, null, 2));

fs.writeFileSync(path.join(DIST, "vercel.json"), JSON.stringify({
  trailingSlash: true,
  redirects: [
    { source: "/blog", destination: "/", permanent: true },
    { source: "/blog/:path*", destination: "/", permanent: true },
  ],
  headers: [
    { source: "/(.*)", headers: [
      { key: "X-Frame-Options", value: "SAMEORIGIN" },
      { key: "X-Content-Type-Options", value: "nosniff" },
      { key: "Referrer-Policy", value: "strict-origin-when-cross-origin" },
      { key: "Permissions-Policy", value: "camera=(), microphone=(), geolocation=()" },
    ] },
    { source: "/assets/(.*)", headers: [{ key: "Cache-Control", value: "public, max-age=604800" }] },
  ],
}, null, 2));

// site.js gets the leads email injected
const js = fs.readFileSync("src/assets/js/site.js", "utf8").replace("__LEADS_EMAIL__", contact.leadsEmail).replace("__WHATSAPP_NUMBER__", whatsapp.number);
fs.writeFileSync(path.join(DIST, "assets/js/site.js"), js);

// ---------- compile Tailwind ----------
execSync(`npx tailwindcss -c tailwind.config.cjs -i styles.css -o ${DIST}/assets/css/site.css --minify`, { stdio: "inherit" });
console.log(`Built ${pages.length + 2} pages into /${DIST}`);
