/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ["./dist/**/*.html", "./src/assets/js/**/*.js"],
  theme: {
    extend: {
      colors: {
        brand: { dark: "#273339", slate: "#111827", gold: "#c5a880", goldHover: "#b3956d", accent: "#f4ece1", cardBg: "#1f2937" },
      },
      fontFamily: { sans: ["Inter", "ui-sans-serif", "system-ui", "sans-serif"] },
    },
  },
  plugins: [],
};
