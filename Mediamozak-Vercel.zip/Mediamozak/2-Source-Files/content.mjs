// ============================================================
//  MEDIAMOZAK WEBSITE CONTENT
//  Edit text here, then run:  node build.mjs
//  The finished website is written to the /dist folder.
// ============================================================

export const site = {
  name: "Mediamozak",
  tagline: "Consulting",
  url: "https://mediamozak.com", // your live domain (used for SEO tags & sitemap)
  title: "Mediamozak | Performance Marketing, SEO & Web Development Agency in Delhi",
  description:
    "Mediamozak is a digital marketing agency in Delhi offering Web Development, Performance Marketing, SEO, Social Media, E-Commerce, Quick Commerce and Lead Generation services.",

  // Optional tracking — paste your REAL IDs here, leave "" to disable.
  googleSiteVerification: "", // just the token, e.g. "abc123XYZ"
  ga4MeasurementId: "",        // e.g. "G-XXXXXXXXXX"
  metaPixelId: "",             // e.g. "123456789012345"
};

export const contact = {
  phone: "+91 79829 84658",
  phoneLink: "+917982984658",
  email: "mediamozak@gmail.com",
  address: "Hari Nagar, West Delhi 110064",
  workingHours: "Monday – Saturday: 9:00 AM – 7:00 PM IST",
  // Every contact-form submission is emailed here
  leadsEmail: "mediamozak@gmail.com",
};

export const whatsapp = {
  enabled: true,
  number: "917982984658",
  message: "Hello Mediamozak Team! I would like to inquire about your marketing services.",
};

export const socials = {
  instagram: "https://www.instagram.com/media_mozak/",
  facebook: "https://www.facebook.com/share/1EfkehvDmL/?mibextid=wwXIfr",
  linkedin: "https://www.linkedin.com/company/mediamozak/",
  youtube: "https://youtube.com/@mediamozak?si=AENxSvUZ7AM4tpxq",
};

export const about = {
  heading: "Empowering Brands with Data-Driven Growth Marketing & Web Solutions",
  subheading:
    "At Mediamozak, we bridge performance art with marketing science to convert impressions into lasting client relationships and scaling sales.",
  mission:
    "Our mission is simple: To equip digital-first brands with scalable digital infrastructure, hyper-targeted ad campaigns, and search supremacy.",
  stats: [
    { value: "5+", label: "Years Experience" },
    { value: "250+", label: "Campaigns Executed" },
    { value: "5M+", label: "Client Revenue Scaled" },
    { value: "99.4%", label: "Client Retention Rate" },
  ],
  teamImage: "https://images.unsplash.com/photo-1522071820081-009f0129c71c?auto=format&fit=crop&w=1200&q=80",
};

export const images = {
  homeBanner: "https://images.unsplash.com/photo-1460925895917-afdab827c52f?auto=format&fit=crop&w=1600&q=80",
};

export const services = [
  {
    slug: "web-development-services",
    title: "Web Development Services",
    icon: "Code",
    shortDesc: "High-performance, ultra-responsive websites and Web Applications custom tailored for high conversions.",
    fullContent:
      "Mediamozak builds enterprise-grade, SEO-ready web platforms with blazing fast speed, sleek UX, and robust mobile responsiveness. From landing pages to enterprise portals, we engineer digital hubs designed to turn visitors into buyers.",
    features: ["Custom React / HTML5 Architecture", "Full On-Page SEO Optimization", "Sub-second Page Load Speed", "Custom CMS Integration"],
    bannerImage: "https://images.unsplash.com/photo-1498050108023-c5249f4df085?auto=format&fit=crop&w=1200&q=80",
  },
  {
    slug: "social-media-marketing-services",
    title: "Social Media Marketing Services",
    icon: "Share2",
    shortDesc: "Creative content, viral campaigns, and community management across Meta, Instagram, LinkedIn & YouTube.",
    fullContent:
      "Build an active, loyal brand community. Mediamozak designs viral visual campaigns, manages organic growth, and runs engagement strategies across Meta, Instagram, LinkedIn, and emerging platforms.",
    features: ["Content Calendar Strategy", "Short-Form Video Reels Creation", "Community Management", "Influencer Collaborations"],
    bannerImage: "/assets/img/social-media-marketing.jpg",
  },
  {
    slug: "performance-marketing-services",
    title: "Performance Marketing Services",
    icon: "TrendingUp",
    shortDesc: "ROI-driven ad campaigns on Google Ads, Meta Ads, and YouTube with algorithmic budget optimization.",
    fullContent:
      "Stop burning ad budgets. Our performance specialists execute laser-targeted campaigns focusing on key metrics like ROAS, CAC, and LTV. We continually split-test ads to maximize revenue per ad dollar.",
    features: ["Google Ads & PPC Management", "Meta Pixel & Conversion API Setup", "A/B Dynamic Ad Creative Testing", "ROAS Optimization"],
    bannerImage: "https://images.unsplash.com/photo-1551288049-bebda4e38f71?auto=format&fit=crop&w=1200&q=80",
  },
  {
    slug: "e-com-marketing",
    title: "E-com Marketing",
    icon: "ShoppingBag",
    shortDesc: "End-to-end sales growth strategies for Shopify, WooCommerce, and custom e-commerce stores.",
    fullContent:
      "Scale your e-commerce store with structured retention and customer acquisition funnels. We optimize product pages, run dynamic remarketing ads, and set up automated email/SMS workflows.",
    features: ["Shopify Store CRO", "Dynamic Product Catalog Ads", "Abandoned Cart Automation Funnels", "Customer Retention Strategy"],
    bannerImage: "/assets/img/ecommerce-marketing.jpg",
  },
  {
    slug: "quick-com-marketing",
    title: "Quick-com Marketing",
    icon: "Zap",
    shortDesc: "Instant commerce visibility & promotion strategies for 10-minute delivery apps and local quick commerce.",
    fullContent:
      "Dominate quick commerce platforms (Blinkit, Zepto, Instamart). We run localized hyper-targeted geo-ads and in-app listing optimization to drive instant sales lifts for FMCG & consumer brands.",
    features: ["In-App Platform Banner Ads", "Hyper-local Micro Targeting", "Stock & Demand Surge Campaigning", "Quick Commerce CRO"],
    bannerImage: "https://images.unsplash.com/photo-1526304640581-d334cdbbf45e?auto=format&fit=crop&w=1200&q=80",
  },
  {
    slug: "lead-generation-services",
    title: "Lead Generation Services",
    icon: "Target",
    shortDesc: "High-intent B2B and B2C qualified lead funnels engineered for high closing rates.",
    fullContent:
      "Fill your sales pipeline with verified, ready-to-buy decision-makers. Mediamozak creates high-converting quiz funnels, landing pages, and multi-channel drip systems to capture high-value leads.",
    features: ["Interactive Qualification Funnels", "Real-Time CRM Sync", "Automated Lead Nurturing", "B2B LinkedIn Outreach"],
    bannerImage: "https://images.unsplash.com/photo-1557804506-669a67965ba0?auto=format&fit=crop&w=1200&q=80",
  },
  {
    slug: "search-engine-optimization",
    title: "Search Engine Optimization (SEO)",
    icon: "Search",
    shortDesc: "First-page ranking strategies combining technical SEO, link building, and intent-targeted content.",
    fullContent:
      "Dominate organic search result pages. Our SEO strategy focuses on technical audit fixes, high domain authority backlinks, local search Google Business Profile optimization, and intent-focused editorial content.",
    features: ["Technical SEO & Core Web Vitals Fixes", "Keyword Intent Mapping", "Authority Link Building", "Google Business Profile Booster"],
    bannerImage: "https://images.unsplash.com/photo-1571786256017-aee7a0c009b6?auto=format&fit=crop&w=1200&q=80",
  },
];

export const faqs = [
  {
    category: "General",
    question: "What makes Mediamozak different from traditional agencies?",
    answer:
      "Mediamozak focuses on measurable business outcomes rather than vanity metrics. We integrate advanced web architecture with direct-response performance ad funnels.",
  },
  {
    category: "Services",
    question: "How long does it take to see results from SEO vs Performance Marketing?",
    answer:
      "Performance marketing can deliver leads and traffic within 24–48 hours of campaign launch, whereas SEO produces compounding long-term organic growth over 3 to 6 months.",
  },
  {
    category: "Pricing",
    question: "Do you offer customized retainer models?",
    answer:
      "Yes! We tailor our retainer models to your specific growth stage—whether you need project-based web development or an all-inclusive growth performance package.",
  },
  {
    category: "Quick-Com",
    question: "What is Quick-com Marketing and how can my brand benefit?",
    answer:
      "Quick-com marketing targets fast delivery apps like Blinkit and Zepto. We optimize your product visibility inside these apps to capture high-intent buyers in real time.",
  },
];

export const legal = {
  updated: "October 20, 2026",
  privacy: [
    ["Introduction", "At Mediamozak, accessible from {URL}, the privacy of our visitors is one of our main priorities. This Privacy Policy explains what information we collect, how we use it, and the choices you have."],
    ["Information we collect", "When you submit our contact form we collect the details you provide: your name, email address, phone number, the service you are interested in and your message. If you contact us on WhatsApp, phone or email, we receive the information you choose to share through that channel."],
    ["How we use your information", "We use the information you submit only to respond to your enquiry, prepare proposals, provide our services and communicate with you about your project. We do not sell or rent your personal information to anyone."],
    ["Form processing", "Contact form submissions sent by email are delivered to our business email inbox through a form-to-email service (FormSubmit). Enquiries sent by WhatsApp go directly to our WhatsApp Business number. Our website is hosted on Vercel. These providers process the data on our behalf solely to deliver your message to us."],
    ["Log files & cookies", "Like most websites, our hosting provider may automatically record standard log information such as IP address, browser type, date and time of visit and referring pages, for security and performance purposes. If we enable analytics or advertising tools (such as Google Analytics or Meta Pixel), they may use cookies to understand how visitors use the site."],
    ["Third-party links", "Our website links to third-party platforms such as WhatsApp, Instagram, Facebook, LinkedIn and YouTube. Their own privacy policies apply when you use those services."],
    ["Data retention & your rights", "We keep enquiry data only as long as needed to respond to you and for legitimate business records. You may ask us to access, correct or delete the personal information you have shared with us at any time by emailing {EMAIL}."],
    ["Contact", "If you have any questions about this Privacy Policy, contact us at {EMAIL} or {PHONE}."],
  ],
  terms: [
    ["Welcome", "These terms and conditions outline the rules for using the Mediamozak website, located at {URL}. By accessing this website you accept these terms. Please do not continue to use the website if you do not agree with them."],
    ["Intellectual property", "Unless otherwise stated, Mediamozak and/or its licensors own the intellectual property rights for all material on this website. You may view and print pages for your own personal use, subject to these terms. You must not republish, sell or redistribute material from this website without our written permission."],
    ["Information on this website", "The content on this website is provided for general information about our services. Results described are indicative and vary from client to client; specific deliverables, timelines and fees are agreed separately in a written proposal or agreement."],
    ["Enquiries", "Submitting an enquiry through this website does not create a client relationship. An engagement begins only once both parties agree to a proposal or contract."],
    ["External links", "This website may contain links to third-party websites. We are not responsible for the content or practices of those websites."],
    ["Limitation of liability", "To the maximum extent permitted by law, Mediamozak will not be liable for any loss arising from the use of this website or reliance on its content."],
    ["Governing law", "These terms are governed by the laws of India, and any disputes are subject to the jurisdiction of the courts of New Delhi."],
    ["Contact", "Questions about these terms can be sent to {EMAIL}."],
  ],
};
