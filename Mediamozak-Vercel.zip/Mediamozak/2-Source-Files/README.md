# Mediamozak website — go-live guide (Vercel)

## 1. Put the site live on Vercel

You need a free GitHub account and a free Vercel account (sign up to Vercel with GitHub).

**Step A — put the website on GitHub (no coding)**
1. Go to https://github.com/new → name it `mediamozak-website` → **Create repository**.
2. On the new repository page, click **uploading an existing file**.
3. Unzip `Mediamozak-Vercel.zip`. Open `1-Website-Upload-to-Vercel/mediamozak-site`, select **everything inside it** (the files and folders, not the folder itself) and drag them onto the GitHub page.
4. Click **Commit changes**.

**Step B — connect it to Vercel**
1. Go to https://vercel.com/new and click **Import** next to `mediamozak-website`.
2. Leave every setting as it is (Framework Preset: **Other**, no build command) and click **Deploy**.
3. In about 30 seconds your site is live at `mediamozak-website.vercel.app`.
4. To use your own domain: **Project → Settings → Domains → Add** `mediamozak.com`, then follow the DNS steps Vercel shows.

Any later change: upload the changed files to the same GitHub repository and Vercel updates the site automatically.

*Option for developers:* inside `mediamozak-site`, run `npx vercel --prod`.

## 2. How enquiries reach you
The contact form has two buttons — the visitor chooses:
- **Send on WhatsApp** → WhatsApp opens with their details already typed, addressed to +91 79829 84658. They press Send and it arrives in your WhatsApp.
- **Send via Email** → the details are emailed to mediamozak@gmail.com (subject starts with "Mediamozak Consulting").

### Turn on email delivery (do this once, after the site is live)
1. Open your live site → Contact Us → fill the form → **Send via Email**.
2. In mediamozak@gmail.com you'll get an email from FormSubmit titled "Activate Form" (check Spam/Promotions too). Click **Activate Form**.
3. Send one more test enquiry — it now lands in your inbox. Done.

If you later connect a new domain (e.g. move from vercel.app to mediamozak.com), repeat these 3 steps once from the new domain.

## 3. Changing text later
All content (contact details, services, FAQs, stats, legal text, social links) lives in `2-Source-Files/content.mjs`.
Edit it, run `npm install` (first time only) and `node build.mjs`, then upload the new `dist` folder's contents to GitHub.

To add Google Analytics, Meta Pixel or Search Console verification, paste your real IDs into the `site` section of `content.mjs` and rebuild.
